#!/bin/bash
# INNK Enerji Takip Sistemi - Başlatıcı

echo ""
echo "╔══════════════════════════════════════════════╗"
echo "║   INNK Enerji Takip Sistemi · ISO 50001      ║"
echo "╚══════════════════════════════════════════════╝"
echo ""

# Gerekli paketleri kontrol et ve kur
echo "⏳ Bağımlılıklar kontrol ediliyor..."
pip install flask werkzeug openpyxl pdfplumber -q

echo "✅ Sistem hazır."
echo ""
echo "🌐 Tarayıcınızda şu adresi açın: http://localhost:5000"
echo "👤 Kullanıcı adı : admin@innk.com"
echo "🔑 Şifre         : innk2025"
echo ""
echo "Durdurmak için CTRL+C tuşlarına basın."
echo ""

python3 app.py
