from flask import Flask, render_template, request, redirect, url_for, session, jsonify, send_file
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3, os, json
from datetime import datetime
from functools import wraps

app = Flask(__name__)
app.secret_key = 'innk-enys-2025-gizli-anahtar'

@app.template_filter('enumerate')
def enumerate_filter(iterable):
    return enumerate(iterable)

@app.context_processor
def inject_now_yil():
    return {'now_yil': datetime.now().year}
# Render.com'da DATA_DIR env var kalıcı disk, lokalde instance/ klasörü
_data_dir = os.environ.get('DATA_DIR', os.path.join(os.path.dirname(__file__), 'instance'))
DB = os.path.join(_data_dir, 'enerji.db')

# TEP dönüşüm katsayıları (ISO 50001 / EPDK)
TEP_KATSAYI = {
    'elektrik':   0.000086,   # kWh → TEP
    'dogalgaz':   0.0008255,  # m³  → TEP
    'su':         0.0,        # su TEP hesabına girmez
}

BIRIM = {
    'elektrik': 'kWh',
    'dogalgaz': 'm³',
    'su':       'm³',
}

AYLAR = ['Ocak','Şubat','Mart','Nisan','Mayıs','Haziran',
         'Temmuz','Ağustos','Eylül','Ekim','Kasım','Aralık']

# ─── DB ──────────────────────────────────────────────────────────────────────

def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    os.makedirs(_data_dir, exist_ok=True)
    conn = get_db()
    c = conn.cursor()
    c.executescript('''
        CREATE TABLE IF NOT EXISTS kullanici (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ad TEXT NOT NULL,
            email TEXT UNIQUE NOT NULL,
            sifre_hash TEXT NOT NULL,
            rol TEXT DEFAULT "editor"
        );
        CREATE TABLE IF NOT EXISTS lokasyon (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ad TEXT NOT NULL UNIQUE,
            aciklama TEXT,
            aktif INTEGER DEFAULT 1
        );
        CREATE TABLE IF NOT EXISTS tuketim (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lokasyon_id INTEGER NOT NULL,
            yil INTEGER NOT NULL,
            ay INTEGER NOT NULL,
            tur TEXT NOT NULL,
            miktar REAL NOT NULL,
            girdi_tarihi TEXT,
            girdi_kisi TEXT,
            FOREIGN KEY (lokasyon_id) REFERENCES lokasyon(id),
            UNIQUE(lokasyon_id, yil, ay, tur)
        );
    ''')
    # Varsayılan admin kullanıcısı
    try:
        c.execute("INSERT INTO kullanici (ad, email, sifre_hash, rol) VALUES (?,?,?,?)",
                  ('Admin', 'admin@innk.com', generate_password_hash('innk2025'), 'admin'))
    except sqlite3.IntegrityError:
        pass
    # Varsayılan lokasyonlar
    for lok in ['Ankara', 'İstanbul']:
        try:
            c.execute("INSERT INTO lokasyon (ad) VALUES (?)", (lok,))
        except sqlite3.IntegrityError:
            pass
    conn.commit()
    conn.close()

# ─── Auth ────────────────────────────────────────────────────────────────────

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if 'user_id' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    return decorated

@app.route('/login', methods=['GET', 'POST'])
def login():
    hata = None
    if request.method == 'POST':
        email = request.form['email']
        sifre = request.form['sifre']
        conn = get_db()
        user = conn.execute("SELECT * FROM kullanici WHERE email=?", (email,)).fetchone()
        conn.close()
        if user and check_password_hash(user['sifre_hash'], sifre):
            session['user_id'] = user['id']
            session['user_ad'] = user['ad']
            session['user_rol'] = user['rol']
            return redirect(url_for('dashboard'))
        hata = 'E-posta veya şifre hatalı.'
    return render_template('login.html', hata=hata)

@app.route('/cikis')
def cikis():
    session.clear()
    return redirect(url_for('login'))

# ─── Dashboard ───────────────────────────────────────────────────────────────

@app.route('/')
@login_required
def dashboard():
    yil = int(request.args.get('yil', datetime.now().year))
    conn = get_db()
    lokasyonlar = conn.execute("SELECT * FROM lokasyon WHERE aktif=1").fetchall()

    # Yıllık özet: her lokasyon, her tür → toplam + TEP
    ozet = []
    for lok in lokasyonlar:
        satirlar = conn.execute("""
            SELECT tur, SUM(miktar) as toplam
            FROM tuketim WHERE lokasyon_id=? AND yil=?
            GROUP BY tur
        """, (lok['id'], yil)).fetchall()
        tep_toplam = sum(r['toplam'] * TEP_KATSAYI.get(r['tur'], 0) for r in satirlar)
        ozet.append({
            'lok': dict(lok),
            'turler': {r['tur']: r['toplam'] for r in satirlar},
            'tep': round(tep_toplam, 4),
        })

    # Aylık elektrik trendi (tüm lokasyonlar)
    trend = {}
    for lok in lokasyonlar:
        aylik = conn.execute("""
            SELECT ay, miktar FROM tuketim
            WHERE lokasyon_id=? AND yil=? AND tur='elektrik'
            ORDER BY ay
        """, (lok['id'], yil)).fetchall()
        trend[lok['ad']] = {r['ay']: r['miktar'] for r in aylik}

    conn.close()
    yillar = list(range(2021, datetime.now().year + 2))
    return render_template('dashboard.html',
                           ozet=ozet, trend=trend, yil=yil, yillar=yillar,
                           aylar=AYLAR, lokasyonlar=lokasyonlar)

# ─── Veri Girişi ─────────────────────────────────────────────────────────────

@app.route('/veri-gir', methods=['GET', 'POST'])
@login_required
def veri_gir():
    conn = get_db()
    lokasyonlar = conn.execute("SELECT * FROM lokasyon WHERE aktif=1").fetchall()

    if request.method == 'POST':
        lok_id = int(request.form['lokasyon_id'])
        yil    = int(request.form['yil'])
        ay     = int(request.form['ay'])
        tarih  = datetime.now().isoformat()
        kisi   = session['user_ad']
        kaydedilen = 0
        for tur in ['elektrik', 'dogalgaz', 'su']:
            deger = request.form.get(tur, '').strip()
            if deger:
                try:
                    miktar = float(deger.replace(',', '.'))
                    conn.execute("""
                        INSERT INTO tuketim (lokasyon_id, yil, ay, tur, miktar, girdi_tarihi, girdi_kisi)
                        VALUES (?,?,?,?,?,?,?)
                        ON CONFLICT(lokasyon_id,yil,ay,tur) DO UPDATE SET
                            miktar=excluded.miktar,
                            girdi_tarihi=excluded.girdi_tarihi,
                            girdi_kisi=excluded.girdi_kisi
                    """, (lok_id, yil, ay, tur, miktar, tarih, kisi))
                    kaydedilen += 1
                except ValueError:
                    pass
        conn.commit()
        conn.close()
        return jsonify({'durum': 'ok', 'kaydedilen': kaydedilen})

    # Mevcut verileri çek (seçili lokasyon + yıl)
    lok_id = request.args.get('lokasyon_id', lokasyonlar[0]['id'] if lokasyonlar else None)
    yil    = int(request.args.get('yil', datetime.now().year))
    mevcut = {}
    if lok_id:
        rows = conn.execute("""
            SELECT ay, tur, miktar FROM tuketim
            WHERE lokasyon_id=? AND yil=?
        """, (lok_id, yil)).fetchall()
        for r in rows:
            mevcut[(r['ay'], r['tur'])] = r['miktar']
    conn.close()
    yillar = list(range(2021, datetime.now().year + 2))
    return render_template('veri_gir.html',
                           lokasyonlar=lokasyonlar, aylar=AYLAR,
                           yillar=yillar, mevcut=mevcut,
                           sec_lok=int(lok_id) if lok_id else None,
                           sec_yil=yil, birim=BIRIM)

# ─── Lokasyon Yönetimi ───────────────────────────────────────────────────────

@app.route('/lokasyonlar', methods=['GET', 'POST'])
@login_required
def lokasyonlar():
    conn = get_db()
    if request.method == 'POST':
        ad = request.form['ad'].strip()
        aciklama = request.form.get('aciklama', '').strip()
        try:
            conn.execute("INSERT INTO lokasyon (ad, aciklama) VALUES (?,?)", (ad, aciklama))
            conn.commit()
        except sqlite3.IntegrityError:
            pass
    loklar = conn.execute("SELECT * FROM lokasyon ORDER BY aktif DESC, ad").fetchall()
    conn.close()
    return render_template('lokasyonlar.html', lokasyonlar=loklar)

@app.route('/lokasyon-toggle/<int:lok_id>')
@login_required
def lokasyon_toggle(lok_id):
    conn = get_db()
    conn.execute("UPDATE lokasyon SET aktif = 1 - aktif WHERE id=?", (lok_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('lokasyonlar'))

# ─── API: Aylık detay ────────────────────────────────────────────────────────

@app.route('/api/aylik')
@login_required
def api_aylik():
    lok_id = request.args.get('lok_id')
    yil    = request.args.get('yil', datetime.now().year)
    conn = get_db()
    rows = conn.execute("""
        SELECT ay, tur, miktar FROM tuketim
        WHERE lokasyon_id=? AND yil=? ORDER BY ay, tur
    """, (lok_id, yil)).fetchall()
    conn.close()
    sonuc = {}
    for r in rows:
        ay = r['ay']
        if ay not in sonuc:
            sonuc[ay] = {'ay_ad': AYLAR[ay-1]}
        sonuc[ay][r['tur']] = r['miktar']
        sonuc[ay][f"{r['tur']}_tep"] = round(r['miktar'] * TEP_KATSAYI.get(r['tur'], 0), 6)
    return jsonify(list(sonuc.values()))

# ─── Excel Export ────────────────────────────────────────────────────────────

@app.route('/export/<int:yil>')
@login_required
def export_excel(yil):
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from openpyxl.utils import get_column_letter
    import io

    conn = get_db()
    lokasyonlar = conn.execute("SELECT * FROM lokasyon WHERE aktif=1").fetchall()

    wb = Workbook()
    wb.remove(wb.active)

    KOYU = "1A3C5E"
    ACIK = "E8F0F7"
    YESIL = "2E7D32"

    thin = Side(style='thin', color='CCCCCC')
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    for lok in lokasyonlar:
        ws = wb.create_sheet(title=lok['ad'])
        rows = conn.execute("""
            SELECT ay, tur, miktar FROM tuketim
            WHERE lokasyon_id=? AND yil=? ORDER BY ay, tur
        """, (lok['id'], yil)).fetchall()
        data = {}
        for r in rows:
            if r['ay'] not in data:
                data[r['ay']] = {}
            data[r['ay']][r['tur']] = r['miktar']

        # Başlık
        ws.merge_cells('A1:H1')
        ws['A1'] = f"ENERJİ TÜKETİM RAPORU — {lok['ad'].upper()} — {yil}"
        ws['A1'].font = Font(bold=True, color='FFFFFF', size=13)
        ws['A1'].fill = PatternFill('solid', fgColor=KOYU)
        ws['A1'].alignment = Alignment(horizontal='center', vertical='center')
        ws.row_dimensions[1].height = 28

        # Kolon başlıkları
        headers = ['Ay', 'Elektrik (kWh)', 'Elektrik TEP', 'Doğalgaz (m³)', 'Doğalgaz TEP', 'Su (m³)', 'Toplam TEP', 'Not']
        for ci, h in enumerate(headers, 1):
            cell = ws.cell(row=2, column=ci, value=h)
            cell.font = Font(bold=True, color='FFFFFF')
            cell.fill = PatternFill('solid', fgColor='2C5F8A')
            cell.alignment = Alignment(horizontal='center')
            cell.border = border
        ws.row_dimensions[2].height = 20

        # Veri satırları
        for ri, ay_no in enumerate(range(1, 13), 3):
            ay_data = data.get(ay_no, {})
            elekt  = ay_data.get('elektrik', 0) or 0
            gaz    = ay_data.get('dogalgaz', 0) or 0
            su     = ay_data.get('su', 0) or 0
            e_tep  = round(elekt * TEP_KATSAYI['elektrik'], 4)
            g_tep  = round(gaz   * TEP_KATSAYI['dogalgaz'], 4)
            tot    = round(e_tep + g_tep, 4)
            fill = PatternFill('solid', fgColor=ACIK) if ri % 2 == 0 else PatternFill('solid', fgColor='FFFFFF')
            row_vals = [AYLAR[ay_no-1], elekt or '', e_tep or '', gaz or '', g_tep or '', su or '', tot or '', '']
            for ci, val in enumerate(row_vals, 1):
                c = ws.cell(row=ri, column=ci, value=val)
                c.fill = fill
                c.border = border
                c.alignment = Alignment(horizontal='center' if ci > 1 else 'left')

        # Toplam satırı
        tot_row = 15
        ws.cell(row=tot_row, column=1, value='TOPLAM').font = Font(bold=True)
        for ci, col in enumerate(['B','C','D','E','F','G'], 2):
            c = ws.cell(row=tot_row, column=ci, value=f"=SUM({col}3:{col}14)")
            c.font = Font(bold=True, color='FFFFFF')
            c.fill = PatternFill('solid', fgColor=YESIL)
            c.border = border
            c.alignment = Alignment(horizontal='center')

        # Sütun genişlikleri
        widths = [12, 16, 14, 16, 14, 12, 14, 10]
        for ci, w in enumerate(widths, 1):
            ws.column_dimensions[get_column_letter(ci)].width = w

    conn.close()
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    fname = f"INNK_ENYS_03_{yil}_TEP_Raporu.xlsx"
    return send_file(buf, download_name=fname,
                     as_attachment=True,
                     mimetype='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')

if __name__ == '__main__':
    init_db()
    print("\n✅ Enerji Takip Sistemi başlatılıyor...")
    print("🌐 Tarayıcıda açın: http://localhost:5000")
    print("👤 Kullanıcı: admin@innk.com  |  Şifre: innk2025\n")
    app.run(debug=True, port=5000)
