# INNK Enerji Takip Sistemi
### ISO 50001 · ENYS.03 · Versiyon 1.0

---

## Kurulum (Tek Seferlik)

Python 3.8+ gereklidir.

```bash
pip install flask werkzeug openpyxl pdfplumber
```

---

## Başlatma

```bash
# Windows
python app.py

# Mac / Linux
bash baslat.sh
```

Tarayıcıda: **http://localhost:5000**

---

## Giriş Bilgileri (Varsayılan)

| Alan | Değer |
|------|-------|
| E-posta | admin@innk.com |
| Şifre | innk2025 |

> ⚠️ Şifreyi değiştirmek için `app.py` içindeki `init_db()` fonksiyonunu düzenleyin.

---

## Kullanım

### 1. Lokasyon Ekle
**Lokasyonlar** sayfasından yeni ofis/tesis ekleyebilirsiniz.  
Varsayılan olarak **Ankara** ve **İstanbul** tanımlıdır.

### 2. Veri Girişi
**Veri Girişi** sayfasında lokasyon ve yılı seçin,  
aylık elektrik (kWh), doğalgaz (m³) ve su (m³) değerlerini girin.  
Kaydet'e basın — TEP hesabı otomatik yapılır.

### 3. Dashboard
Tüm lokasyonların yıllık özetini, TEP değerlerini  
ve aylık trend grafiğini görürsünüz.

### 4. Excel İndir
Dashboard'dan veya sidebar'dan **Excel İndir** butonuyla  
INNK ENYS.03 formatında rapor indirilir.

---

## TEP Dönüşüm Katsayıları

| Enerji Türü | Katsayı | Kaynak |
|-------------|---------|--------|
| Elektrik | 0.000086 TEP/kWh | EPDK / TEIAS |
| Doğalgaz | 0.0008255 TEP/m³ | BOTAŞ |
| Su | — | TEP hesabına girmez |

---

## Dosya Yapısı

```
enerji-app/
├── app.py              → Ana uygulama (Flask)
├── baslat.sh           → Kolay başlatma scripti
├── instance/
│   └── enerji.db       → SQLite veritabanı (otomatik oluşur)
└── templates/
    ├── base.html
    ├── login.html
    ├── dashboard.html
    ├── veri_gir.html
    └── lokasyonlar.html
```

---

## Gelecek Aşamalar

- [ ] PDF fatura parse (Aşama 2)
- [ ] Kullanıcı yönetimi / şifre değiştirme (Aşama 2)
- [ ] SEU / EnPI takibi (Aşama 3)
- [ ] 2021–2024 geçmiş veri import (Aşama 3)
- [ ] Otomatik enerji referans çizgisi hesabı (Aşama 4)
